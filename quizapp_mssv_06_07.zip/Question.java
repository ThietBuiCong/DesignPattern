/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ou.quizapp_mssv;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author admin
 */
public class Question implements Cloneable {

    private int id;
    private String content;
    private String hint;
    private int level_id;
    private int category_id;
    private String image;
    private List<Choice> choices;

    @Override
    protected Object clone() {
        try {
            Question copy = (Question) super.clone();
            copy.choices = new ArrayList<>(this.choices);
            return copy;
        } catch (CloneNotSupportedException ex) {
            Logger.getLogger(Question.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    public Question(String content, String hint, int level_id, int category_id, String image, List<Choice> choices) {
        this.content = content;
        this.hint = hint;
        this.level_id = level_id;
        this.category_id = category_id;
        this.image = image;
        this.choices = choices;
    }
    
    private Question(Builder builder){
        this.id = builder.id;
        this.content = builder.content;
        this.hint = builder.hint;
        this.level_id = builder.level_id;
        this.category_id = builder.category_id;
        this.image = builder.image;
        this.choices = builder.choices;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getHint() {
        return hint;
    }

    public void setHint(String hint) {
        this.hint = hint;
    }

    public int getLevel_id() {
        return level_id;
    }

    public void setLevel_id(int level_id) {
        this.level_id = level_id;
    }

    public int getCategory_id() {
        return category_id;
    }

    public void setCategory_id(int category_id) {
        this.category_id = category_id;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public List<Choice> getChoices() {
        return choices;
    }

    public void setChoices(List<Choice> choices) {
        this.choices = choices;
    }

    public static class Builder {

        private int id;
        private String content;
        private String hint;
        private int level_id;
        private int category_id;
        private String image;
        private List<Choice> choices;
        
        public Builder id(int id){
            this.id = id;
            return this;
        }
        
        public Builder content(String content){
            this.content = content;
            return this;
        }
        
        public Builder hint(String hint){
            this.hint = hint;
            return this;
        }
        
        public Builder levelId(int level_id){
            this.level_id = level_id;
            return this;
        }
        
        public Builder categoryId(int categoryId){
            this.category_id = categoryId;
            return this;
        }
        
        public Builder choices(List<Choice> choices){
            this.choices = choices;
            return this;
        }
        
        public Question build(){
            return new Question(this);
        }
    }

}
