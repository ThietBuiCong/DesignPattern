/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ou.quizapp_mssv;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class QuestionQueryBuilder {
    private Integer categoryId;
    private Integer levelId;
    private String keyword;
    
    private int limit = 5;
    private List<Object> params = new ArrayList<>();
    
    public QuestionQueryBuilder(){        
    }

    public QuestionQueryBuilder(Integer categoryId) {
        this.categoryId = categoryId;
        this.levelId = null;
    }

    public QuestionQueryBuilder(Integer categoryId, Integer levelId) {
        this.categoryId = categoryId;
        this.levelId = levelId;
    }
    
    public QuestionQueryBuilder keyword(String keyword){
        this.keyword = keyword;
        return this;
    }
    
    public QuestionQueryBuilder levelId(Integer level_id){
        this.levelId = level_id;
        return this;
    }
    
    public QuestionQueryBuilder limit(int limit){
        this.limit = limit;
        return this;
    }
    
    public QuestionQueryBuilder categoryId(Integer categoryId){
        this.categoryId = categoryId;
        return this;
    }
    
    public String build(){
        StringBuilder builder = new StringBuilder();
        
        builder.append("SELECT q.id, q.content, q.hint, q.image,"
                + " c.name AS category, l.name AS level");
        builder.append(" FROM question q ");
        builder.append(" JOIN category c ON c.id = q.category_id");
        builder.append(" JOIN level l ON l.id = q.level_id");
        builder.append(" WHERE 1 = 1");
        
        if(keyword != null && !keyword.trim().isEmpty()){
            builder.append(" AND q.content LIKE ?");
            params.add("%" + keyword.trim()+ "%");
        }
        
        if(categoryId != null){
            builder.append(" AND q.id = ?");
            params.add(categoryId);
        }
        
        if(levelId != null){
            builder.append(" AND l.id = ?");
            params.add(levelId);
        }
        
        builder.append(" ORDER BY RANDOM() LIMIT ?");
        params.add(limit);
        
        return builder.toString();
    }

    public List<Object> getParams() {
        return params;
    }    
}
