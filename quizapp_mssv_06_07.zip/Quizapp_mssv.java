/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.ou.quizapp_mssv;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author admin
 */
public class Quizapp_mssv extends Application {
    
    private ThemeFactory currTheme;
    private ThemeType currentThemeType = ThemeType.DEFAULT_THEME;
    private Stage mainStage;
    
    private List<Question> practiceQuestion = new ArrayList<>();
    private int currQuestionIdx = 0;
    
    public static void main(String[] args) {
        launch(args);
    }
    
    @Override
    public void start(Stage stage) throws Exception {
        this.mainStage = stage;
        currTheme = ThemeFactoryProducer.getFactory(currentThemeType);
        showHome();
    }
    
    private void showHome() {
        Label title = new Label("QUIZAPP - MSSV.");
        title.setStyle(currTheme.getTitleStyle());
        
        Button btnQuestion = new Button("Quản lý câu hỏi");
        btnQuestion.setPrefWidth(250);
        btnQuestion.setStyle(currTheme.getButtonStyle());
        
        btnQuestion.setOnAction(e -> showQuestionMgtForm());
        
        Button btnPractice = new Button("Luyện tập");
        btnPractice.setPrefWidth(250);
        btnPractice.setStyle(currTheme.getButtonStyle());        
        
        btnPractice.setOnAction(e -> showPracticeForm());

        //System.out.println("SQL: "+ queryBuilder.levelId(1).categoryId(1).build());
        Button btnExam = new Button("Luyện thi");
        btnExam.setPrefWidth(250);
        btnExam.setOnAction(e -> MyAlert.getInstance()
                .showMessage("Đây là chức năng luyện thi"));
        btnExam.setStyle(currTheme.getButtonStyle());
        
        ComboBox<ThemeType> cbTheme = new ComboBox<>();
        cbTheme.getItems().addAll(ThemeType.DEFAULT_THEME,
                ThemeType.DARK_THEME, ThemeType.LIGHT_THEME);
        
        cbTheme.setValue(currentThemeType);
        cbTheme.setPrefWidth(250);
        cbTheme.setOnAction(e -> {
            currentThemeType = cbTheme.getValue();
            currTheme = ThemeFactoryProducer.getFactory(currentThemeType);
            showHome();
        });
        
        VBox root = new VBox(15);
        root.setAlignment(Pos.CENTER);
        root.setStyle(currTheme.getBackgroundStyle());
        root.getChildren().addAll(title, btnQuestion,
                btnPractice, btnExam, cbTheme);
        
        Scene scene = new Scene(root, 640, 480);
        this.mainStage.setScene(scene);
        this.mainStage.show();
    }
    
    private void showQuestionMgtForm() {
        Label title = new Label("QUẢN LÝ CÂU HỎI");
        title.setStyle(currTheme.getTitleStyle());
        title.setAlignment(Pos.CENTER);
        
        TextField txtQuestion = new TextField();
        txtQuestion.setPromptText("Nhập nội dung câu hỏi");
        txtQuestion.setMaxWidth(500);
        txtQuestion.setAlignment(Pos.TOP_LEFT);
        
        TextField txtHint = new TextField();
        txtHint.setPromptText("Nhập gợi ý");
        txtHint.setAlignment(Pos.TOP_LEFT);
        txtQuestion.setMaxWidth(500);
        
        ComboBox<String> cbCategory = new ComboBox<>();
        cbCategory.getItems().addAll("Grammar", "Vocabulary", "Reading");
        
        ComboBox<String> cbLevel = new ComboBox<>();
        cbLevel.getItems().addAll("Easy", "Medium", "Hard");
        
        HBox hbCombo = new HBox(10, cbCategory, cbLevel);
        
        RadioButton rdA = new RadioButton();
        TextField txtA = new TextField();
        txtA.setPromptText("Nhập đáp án A");
        RadioButton rdB = new RadioButton();
        TextField txtB = new TextField();
        txtB.setPromptText("Nhập đáp án B");
        RadioButton rdC = new RadioButton();
        TextField txtC = new TextField();
        txtC.setPromptText("Nhập đáp án C");
        RadioButton rdD = new RadioButton();
        TextField txtD = new TextField();
        txtD.setPromptText("Nhập đáp án D");
        
        ToggleGroup correctGroup = new ToggleGroup();
        rdA.setToggleGroup(correctGroup);
        rdA.setUserData("A");
        
        rdB.setToggleGroup(correctGroup);
        rdB.setUserData("B");
        rdC.setToggleGroup(correctGroup);
        rdC.setUserData("C");
        rdD.setToggleGroup(correctGroup);
        rdD.setUserData("D");
        
        HBox row1 = new HBox(10, rdA, txtA, rdB, txtB);
        HBox row2 = new HBox(10, rdC, txtC, rdD, txtD);
        
        Button btnBack = new Button("Quay lại");
        
        btnBack.setOnAction(e -> {
            showHome();
        });
        
        Button btnAddQuestion = new Button("Thêm câu hỏi");
        btnAddQuestion.setOnAction(e -> {
            if (txtQuestion.getText().trim().isEmpty() || txtHint.getText().trim().isEmpty()) {
                MyAlert.getInstance().showError("Vui lòng nhập câu hỏi và gợi ý.");
                return;
            }
            
            if (txtA.getText().trim().isEmpty() || txtB.getText().trim().isEmpty()) {
                MyAlert.getInstance().showError("Vui lòng nhập đáp án.");
                return;
            }
            
            if (correctGroup.getSelectedToggle() == null) {
                MyAlert.getInstance().showError("Vui lòng chọn đáp án đúng.");
                return;
            }
            
            if (cbCategory.getValue() == null || cbLevel.getValue() == null) {
                MyAlert.getInstance().showError("Vui long chon danh muc");
                return;
            }
            
            int category_id = getCategoryId(cbCategory.getValue());
            int level_id = getLevel_Id(cbLevel.getValue());
            String correctAnswer = correctGroup.getSelectedToggle().getUserData().toString();
            
            ArrayList<Choice> choices = new ArrayList<>();
            choices.add(new Choice(txtA.getText().trim(), correctAnswer.equals("A")));
            choices.add(new Choice(txtB.getText().trim(), correctAnswer.equals("B")));
            choices.add(new Choice(txtC.getText().trim(), correctAnswer.equals("C")));
            choices.add(new Choice(txtD.getText().trim(), correctAnswer.equals("D")));            
            
            Question question = new Question(txtQuestion.getText().trim(), txtHint.getText().trim(),
                    level_id, category_id, "", choices);

            //boolean result = addQuestionToDB(txtQuestion.getText().trim(), txtHint.getText().trim(),
            //        category_id, level_id, txtA.getText().trim(), txtB.getText().trim(),
            //        txtC.getText().trim(), txtD.getText().trim(), correctAnswer);
            boolean result = addQuestionToDB(question);
            
            if (result) {
                MyAlert.getInstance().showMessage("Thêm Câu hỏi thành Công");
                txtQuestion.clear();
                txtHint.clear();
                txtA.clear();
                txtB.clear();
                txtC.clear();
                txtD.clear();
                cbCategory.setValue(null);
                cbLevel.setValue(null);
                correctGroup.selectToggle(null);
            } else {
                MyAlert.getInstance().showMessage("Thêm Câu hỏi thất bại.");
            }
            
        });
        
        HBox hbBtn = new HBox(btnBack, btnAddQuestion);
        
        VBox root = new VBox(15);
        root.setStyle(currTheme.getBackgroundStyle());
        root.getChildren().addAll(title, txtQuestion, txtHint, hbCombo, row1, row2, hbBtn);
        
        Scene scene = new Scene(root, 640, 480);
        this.mainStage.setScene(scene);
        this.mainStage.show();
    }
    
    private boolean addQuestionToDB(String questionContent, String hint, int category_id,
            int level_id, String strA, String strB, String strC, String strD, String correctAnswer) {
        
        try {
            Connection conn = JdbcConnector.getInstance().connect();
            
            String sqlQuestion = "INSERT INTO question(content, hint, image, category_id, level_id) "
                    + "VALUES (?,?,?,?,?)";
            
            PreparedStatement stmt = conn.prepareStatement(sqlQuestion, Statement.RETURN_GENERATED_KEYS);
            
            stmt.setString(1, questionContent);
            stmt.setString(2, hint);
            stmt.setString(3, "");
            stmt.setInt(4, category_id);
            stmt.setInt(5, level_id);
            
            stmt.executeUpdate();
            
            ResultSet rs = stmt.getGeneratedKeys();
            int questionId = -1;
            if (rs.next()) {
                questionId = rs.getInt(1);
            }
            
            if (questionId == -1) {
                return false;
            }
            
            insertChoice(conn, strA, correctAnswer.equals("A"), questionId);
            insertChoice(conn, strB, correctAnswer.equals("B"), questionId);
            insertChoice(conn, strC, correctAnswer.equals("C"), questionId);
            insertChoice(conn, strD, correctAnswer.equals("D"), questionId);            
            
            stmt.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Quizapp_mssv.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    private boolean addQuestionToDB(Question question) {
        
        try {
            Connection conn = JdbcConnector.getInstance().connect();
            
            String sqlQuestion = "INSERT INTO question(content, hint, image, category_id, level_id) "
                    + "VALUES (?,?,?,?,?)";
            
            PreparedStatement stmt = conn.prepareStatement(sqlQuestion, Statement.RETURN_GENERATED_KEYS);
            
            stmt.setString(1, question.getContent());
            stmt.setString(2, question.getHint());
            stmt.setString(3, question.getImage());
            stmt.setInt(4, question.getCategory_id());
            stmt.setInt(5, question.getLevel_id());
            
            stmt.executeUpdate();
            
            ResultSet rs = stmt.getGeneratedKeys();
            int questionId = -1;
            if (rs.next()) {
                questionId = rs.getInt(1);
            }
            
            if (questionId == -1) {
                return false;
            }
            
            for (Choice choice : question.getChoices()) {
                choice.setQuestion_id(questionId);
                insertChoice(conn, choice);
            }            
            
            stmt.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Quizapp_mssv.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    private void insertChoice(Connection conn, String choice, boolean correctAnswer, int questionId) {
        String sqlChoice = "INSERT INTO choice(content, is_correct, question_id)"
                + "VALUES(?,?,?)";
        
        try {
            PreparedStatement stmt = conn.prepareStatement(sqlChoice);
            stmt.setString(1, choice);
            stmt.setBoolean(2, correctAnswer);
            stmt.setInt(3, questionId);
        } catch (SQLException ex) {
            Logger.getLogger(Quizapp_mssv.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void insertChoice(Connection conn, Choice choice) {
        String sqlChoice = "INSERT INTO choice(content, is_correct, question_id)"
                + "VALUES(?,?,?)";
        
        try {
            PreparedStatement stmt = conn.prepareStatement(sqlChoice);
            stmt.setString(1, choice.getContent());
            stmt.setBoolean(2, choice.isCorrect());
            stmt.setInt(3, choice.getQuestion_id());
        } catch (SQLException ex) {
            Logger.getLogger(Quizapp_mssv.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private Integer getCategoryId(String value) {
        if(value == null || value.equals("Tất cả"))
            return null;
        
        return switch (value) {
            case "Grammar" ->
                1;
            case "Vocabulary" ->
                2;
            case "Reading" ->
                3;
            default ->
                null;
        };
    }
    
    private Integer getLevel_Id(String value) {
        if(value == null || value.equals("Tất cả"))
            return null;        
        
        return switch (value) {
            case "Easy" ->
                1;
            case "Medium" ->
                2;
            case "Hard" ->
                3;
            default ->
                1;
        };
    }
    
    private void showPracticeForm() {
        Label title = new Label("Thiết lập Câu hỏi");
        title.setAlignment(Pos.CENTER);
        
        TextField txtKeyWord = new TextField();
        txtKeyWord.setPromptText("Nhập từ khóa");
        txtKeyWord.setMaxWidth(300);        
        
        ComboBox<String> cbLevel = new ComboBox<>();
        cbLevel.getItems().addAll("Tất cả", "Easy", "Medium", "Hard");
        cbLevel.setValue("Tất cả");
        
        ComboBox<String> cbCategory = new ComboBox<>();
        cbCategory.getItems().addAll("Tất cả", "Grammar", "Vocabulary", "Reading");
        cbCategory.setValue("Tất cả");
        
        TextField txtNumber = new TextField();
        txtNumber.setPromptText("Nhập số câu hỏi ");
        
        Button btnBack = new Button("Quay lại");
        btnBack.setOnAction(e -> {
            showHome();
        });
        Button btnStart = new Button("Bắt đầu luyện tập");
        btnStart.setOnAction(e->{
            if(txtNumber.getText().trim().isEmpty()){
                MyAlert.getInstance().showMessage("Vui long nhap so cau hoi.");
                return;
            }   
            
            Integer number = Integer.valueOf(txtNumber.getText().trim());
            Integer categoryId = getCategoryId(cbCategory.getValue());
            Integer levelId = getLevel_Id(cbCategory.getValue());
            
            QuestionRepository repo = new QuestionRepository();
            practiceQuestion = repo.getQuestionByFilter(txtKeyWord.getText(), categoryId, levelId, number);           
                         
            if(practiceQuestion.isEmpty()){
                MyAlert.getInstance().showMessage("Khong co cau hoi duoc chon.");
                return;
            }
            //MyAlert.getInstance().showMessage("So luong cau hoi:" + practiceQuestion.size());
            
            showPracticeQuestion();
            
        });
        
        VBox root = new VBox(15);
        root.setStyle(currTheme.getBackgroundStyle());
        root.getChildren().addAll(title, txtKeyWord, cbLevel, cbCategory, txtNumber, btnBack, btnStart);
        
        Scene scene = new Scene(root, 640, 480);
        this.mainStage.setScene(scene);
    }
    
    private void showPracticeQuestion(){
        Question q = practiceQuestion.get(currQuestionIdx);
        
        Label title = new Label("Câu hỏi: "+ (currQuestionIdx + 1 ) +"/" + practiceQuestion.size());
        
        Label lbQuestion = new Label(q.getContent());
        lbQuestion.setWrapText(true);
        lbQuestion.setMaxWidth(500);
        
        VBox answerBox = new VBox(10);
        answerBox.setAlignment(Pos.CENTER_LEFT);
        answerBox.setMaxWidth(500);
        
        ToggleGroup correctGroup = new ToggleGroup();
        for (Choice choice : q.getChoices()) {
            RadioButton rdA = new RadioButton(choice.getContent());
            rdA.setToggleGroup(correctGroup);
            rdA.setUserData(choice);  
            answerBox.getChildren().add(rdA);
        }
        
        Label resultLabel = new Label();
        
        Button btnCheck = new Button("Kiểm tra");
        Button btnNext = new Button("Câu tiếp theo");
        Button btnBack = new Button("Về trang chủ");
        
        btnCheck.setPrefWidth(200);
        btnNext.setPrefWidth(200);
        btnBack.setPrefWidth(200);
        
        btnCheck.setOnAction(e ->{
            RadioButton selected = (RadioButton) correctGroup.getSelectedToggle();
            
            if(selected == null){
                resultLabel.setText("Vui lòng chọn một đáp án.");
                return;
            }
            
            Choice choice = (Choice) selected.getUserData();
            if(choice.isCorrect())
                resultLabel.setText("Chính xác.");
            else
                resultLabel.setText("Chưa chính xác.");
        });
        
        btnNext.setOnAction(e->{
            currQuestionIdx ++;
            if(currQuestionIdx >= practiceQuestion.size()){
                MyAlert.getInstance().showMessage("Bạn đã hoàn thành luyện tập.");
                return;
            }
            else{
                showPracticeQuestion();
            }
        });
        
        btnBack.setOnAction(e->{showHome();});
        
        VBox root = new VBox(15);
        root.setStyle(currTheme.getBackgroundStyle());
        root.getChildren().addAll(title, lbQuestion,answerBox, resultLabel, 
                btnCheck, btnNext, btnBack);
        
        Scene scene = new Scene(root, 640, 480);
        this.mainStage.setScene(scene);
        this.mainStage.show();
    }
}
